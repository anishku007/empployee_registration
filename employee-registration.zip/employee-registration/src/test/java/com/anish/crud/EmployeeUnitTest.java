package com.anish.crud;

import static org.assertj.core.api.Assertions.assertThat;

import com.anish.crud.entities.Employee;
import org.junit.Test;

public class EmployeeUnitTest {

    @Test
    public void whenCalledGetName_thenCorrect() {
        Employee employee = new Employee(1, "Julie", "Cooper","M", "12/08/1992", "Dev");

        assertThat(employee.getFirstName()).isEqualTo("Julie");
    }


    @Test
    public void whenCalledSetName_thenCorrect() {
        Employee employee = new Employee(1, "Julie", "Cooper", "M", "12/08/1992", "Dev");

        employee.setFirstName("John");

        assertThat(employee.getFirstName()).isEqualTo("John");
    }

    @Test
    public void whenCalledtoString_thenCorrect() {
        Employee employee = new Employee(1, "Julie", "Cooper","M", "12/08/1992", "Dev");
        assertThat(employee.toString()).isNotEqualTo("Employee{id=1, name=Julie, email=julie@domain.com}");
    }
}
